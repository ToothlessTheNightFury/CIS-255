enum GuessResult {
    TOO_LOW,
    TOO_HIGH,
    CORRECT,
    BEAT_GAME;
}